//
//  ViewController.swift
//  OutlineViewDemo
//
//  Created by Gabriel Theodoropoulos.
//  Copyright © 2019 Appcoda. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

    // MARK: - IBOutlet Properties
    
    @IBOutlet weak var outlineView: NSOutlineView!
    
    @IBOutlet weak var containerView: NSView!
    
    
    // MARK: - Properties
    
    var viewModel = ViewModel()
    
    lazy var colorDetailsView: ColorDetailsView = {
        let view = ColorDetailsView()
        view.delegate = self
        view.isHidden = true
        self.containerView.addSubview(view)
        view.translatesAutoresizingMaskIntoConstraints = false
        view.centerXAnchor.constraint(equalTo: self.containerView.centerXAnchor).isActive = true
        view.centerYAnchor.constraint(equalTo: self.containerView.centerYAnchor).isActive = true
        view.widthAnchor.constraint(equalTo: self.containerView.widthAnchor).isActive = true
        view.heightAnchor.constraint(equalToConstant: 400.0).isActive = true
        return view
    }()
    
    
    // MARK: - VC Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    
    // MARK: - IBAction Methods
    
    @IBAction func createCollection(_ sender: Any) {
        
    }
    
    
    @IBAction func addColor(_ sender: Any) {
        
    }
    

    @IBAction func removeItem(_ sender: Any) {
        
    }
    
}



// MARK: - ColorDetailsViewDelegate
extension ViewController: ColorDetailsViewDelegate {
    func shouldUpdateColor(withRed red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        
    }
}



// MARK: - NSTextFieldDelegate
extension ViewController: NSTextFieldDelegate {
    
}
